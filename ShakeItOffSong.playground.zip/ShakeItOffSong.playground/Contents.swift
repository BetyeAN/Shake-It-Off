//: Playground - noun: a place where people can play

import Foundation

var firstLine: String = "I shake it off, I shake it off"
var Break: String = " Heartbreak gonna"
var beginnings: [String] = ["Heartbreakers gonna","And the fakers gonna","Baby, I'm just gonna"]
var endings: [String] = ["break","fake","shake"]




func Chorus(){
    
    func fiveTimes(index: Int) -> String {
        var ending = ""
        for x in 0...4{
            ending += endings[index]
            ending += " "
        }
        return ending
    }
    
    for index in 0...2
    { print("\(beginnings[index]), \(fiveTimes(index:index))")
    }
        
   
}

Chorus()

func shakeItOff1 (repeated: String) {
    print(firstLine)
        for x in 0...2 {
            print ("\(repeated)",firstLine)
    }
}

shakeItOff1(repeated: "I,")
